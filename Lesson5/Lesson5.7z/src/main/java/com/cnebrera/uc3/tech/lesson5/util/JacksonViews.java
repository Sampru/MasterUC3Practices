package com.cnebrera.uc3.tech.lesson5.util;

/**
 * ------------------------------------------------
 * @author Francisco Manuel Benitez Chico (XE30001)
 * ------------------------------------------------
 */
public class JacksonViews
{
	/**
	 * Empty subclass
	 */
	public static class Lesson5View extends JacksonViews.Public
	{
		// Empty subclass
	}

	/**
	 * Empty subclass
	 */
	public static class Public
	{
		// Empty subclass
	}
}