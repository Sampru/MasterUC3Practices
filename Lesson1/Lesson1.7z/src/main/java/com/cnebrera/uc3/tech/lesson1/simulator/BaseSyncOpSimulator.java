package com.cnebrera.uc3.tech.lesson1.simulator;

public abstract class BaseSyncOpSimulator
{
    public abstract void executeOp();
}
